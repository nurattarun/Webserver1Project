<?php session_start(); ?>


<!DOCTYPE html>
<html>
<head>
    <title>Login Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="jumbotron text-center" style="background-color: #3b5998; color: yellow;">
            <h2>Welcome to Game Quiz</h2>
        </div>
        <?php
            if(isset($_POST['login'])){
                $username = $_POST['username'];
                $password = $_POST['password'];

                // Verify username and password from database
                // If valid, redirect to home page
                // Otherwise, display error message
            } elseif (isset($_POST['signup'])) {
                // Redirect to the registration page
                header("Location: registration.php");
                exit();
            } elseif (isset($_POST['reset_password'])) {
                // Redirect to the reset password page
                header("Location: resetpass.php");
                exit();
            }
        ?>
        <form method="post" action="" class="form">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" class="form-control">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" class="form-control">
            </div>
            <div class="form-group">
                <input type="submit" name="login" value="Connect" class="btn btn-primary">
                <input type="submit" name="signup" value="Sign-Up" class="btn btn-secondary">
                <input type="submit" name="reset_password" value="Modify Password" class="btn btn-secondary">
            </div>
        </form>
        <?php
        include('db.php');
        if(isset($_POST['login']))
        {
            $username = $_POST['username'];
            $password = $_POST['password'];

            $query = mysqli_query($conn, "SELECT * FROM `admin` WHERE username ='$username' and password ='$password'");
            $row = mysqli_num_rows($query);
            if($row == 1)
            {
                $_SESSION['admin'] = 'admin';
                echo'
                    <script>
                    alert("logged in");
                    window.location="level5.php";
                    </script>
                    ';
            }
            else
            {
                echo'
                    <script>
                    alert("Please enter correct details!");
                    window.location="Login.php";
                    </script>
                    ';

            }
        }
        ?>
    </div>
</body>
</html>
