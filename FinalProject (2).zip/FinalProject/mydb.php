<?php
// Database information
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "DatabaseGame";

// Connect to MySQL server and select the database
try {
    $dbh = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    // Set error mode to exception
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected to database successfully.";

    // Create the table for user information
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(30) NOT NULL,
        last_name VARCHAR(30) NOT NULL,
        username VARCHAR(50) NOT NULL,
        password VARCHAR(255) NOT NULL
    )";
    $dbh->exec($sql);
    echo "Table 'users' created successfully.";

    // Create the table for session results
    $sql = "CREATE TABLE IF NOT EXISTS session_results (
        id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT(11) UNSIGNED NOT NULL,
        date_time DATETIME NOT NULL,
        result ENUM('win', 'fail', 'incomplete') NOT NULL,
        lives_used INT(11) UNSIGNED NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )";
    $dbh->exec($sql);
    echo "Table 'session_results' created successfully.";

    // Insert a sample user
    $sql = "INSERT INTO users (first_name, last_name, username, password)
        VALUES ('jane', 'doeee', 'tk77', '123')";
    $dbh->exec($sql);
    echo "User inserted successfully.";

} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
