<?php
$count =1;
// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the user's answers from the form submission
    $input = $_POST['input'];

    // Get the correct answers from the hidden inputs in the form
    $letters = $_POST['letters'];
    sort($letters); // sort the letters alphabetically

    
    // check if input is in alphabetical order
    if (implode('', $input) === implode('', $letters)) {
        echo '<p>Congratulations! You sorted the letters correctly.</p>';
        echo '<p>Your Letters: '.implode(', ', $input).'</p>';
        echo '<form action="level2.php" method="post"><input type="submit" value="Go to Next Level"></form>';
       // echo '<a href="signout.php" target="_self">Sign Out</a>';
       // echo '<a href="stop_session.php" target="_self">Stop this Session</a>';
    } else {
        // Display wrong message
        echo '<p>Sorry, you sorted the letters incorrectly. Please try again.</p>';
        echo '<p>Your Letters: '.implode(', ', $input).'</p>';
        echo '<a href="level1.php" target="_self">Try Again this Level</a>';
        echo '<a href="Login.php" target="_self">Sign Out</a>';
        echo '<a href="stop_session.php" target="_self">Stop this Session</a>';
        $count++
    }
    
} else {
    // Generate 6 random letters
    $letters = array();
    while (count($letters) < 6) {
        $letter = chr(rand(97, 122));
        if (!in_array($letter, $letters)) {
            $letters[] = $letter;
        }
    }
    sort($letters); // sort the letters alphabetically
    shuffle($letters); // shuffle the letters randomly
}
?>

<!-- HTML form -->
<!DOCTYPE html>
<html>
<head>
  
    <title>Game Level 1</title>
    <style>
/* style for the body */
body {
    font-family: Arial, sans-serif;
    background-color: #ffffcc;
    color: #333;
    margin: 0;
    padding: 0;
}

/* style for the header */
h1 {
    font-size: 2em;
    text-align: center;
    margin-top: 2em;
}

/* style for the paragraph text */
p {
    font-size: 1.2em;
    line-height: 1.5;
    margin: 1em 0;
}

/* style for the form inputs */
label {
    display: block;
    margin: 1em 0;
    font-size: 1.2em;
}

input[type="text"] {
    padding: 0.5em;
    font-size: 1.2em;
    border: 2px solid #ccc;
    border-radius: 5px;
    outline: none;
}

input[type="submit"] {
    margin-top: 2em;
    padding: 0.5em 1em;
    font-size: 1.2em;
    background-color: #FFA500;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

a {
    display: block;
    margin-top: 1em;
    font-size: 1.2em;
    color: #333;
    text-decoration: none;
}

a:hover {
    color: #666;
}

/* Additional CSS for input fields and buttons alignment */
form {
    display: flex;
    flex-direction: column;
    align-items: center;
}

label {
    display: flex;
    justify-content: center;
}

input[type="text"] {
    margin: 0 0 10px 0;
}

input[type="submit"] {
    margin-top: 20px;
    margin-bottom: 10px;
}

</style>
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f1f1f1;
    }

    .game-container {
        border: 1px solid #ccc;
        padding: 20px;
        border-radius: 10px;
        background-color: #fff;
        max-width: 600px;
        margin: 0 auto;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    }

    h1 {
        font-size: 28px;
        margin-bottom: 20px;
        text-align: center;
    }

    p {
        font-size: 18px;
        line-height: 1.5;
        margin-bottom: 20px;
    }

    input[type="text"] {
        width: 30px;
        height: 30px;
        text-align: center;
        font-size: 24px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-right: 10px;
    }

    input[type="submit"] {
        background-color: #4CAF50;
        border: none;
        color: #fff;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 18px;
        margin-top: 20px;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    input[type="submit"]:hover {
        background-color: #3e8e41;
    }

    a {
        display: block;
        font-size: 16px;
        margin-top: 20px;
        text-align: center;
        color: #888;
        text-decoration: none;
        transition: color 0.3s ease;
    }

    a:hover {
        color: #333;
    }
</style>

<body>
    <div style="border: 1px solid #ccc; padding: 10px;">
        <h1 style="font-size: 24px;">Game Level 1: Order alphabets in ascending order</h1>
        <p style="font-size: 18px;">A set of 6 different letters generated randomly is shown below. Please use the form available to write them in ascending order (from a to z).</p>
        <p style="font-size: 20px;"><?php echo implode(', ', $letters); ?></p>
        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
            <?php foreach ($letters as $letter) { ?>
            <input type="hidden" name="letters[]" value="<?php echo $letter; ?>" maxlength="1" size="1">
            <label style="font-size: 20px;">
                <input type="text" name="input[]" minlength="1" maxlength="1" required style="font-size: 24px; width: 50px;">
            </label>
            <br>
            <?php } ?>
            <input type="submit" value="Submit" style="font-size: 20px; padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
        </form>
    </div>
    <a href="Login.php" target="_self" style="font-size: 20px;">Sign Out</a>
    <a href="stop_session.php" target="_self" style="font-size: 20px;">Stop this Session</a>
</body>



</html>
