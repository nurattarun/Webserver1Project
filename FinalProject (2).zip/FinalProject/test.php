<?php
// Database information
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "DatabaseGame";

// Connect to MySQL server and select the database
try {
    $dbh = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    // Set error mode to exception
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected to database successfully.";

    // Create the table for user information
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(30) NOT NULL,
        last_name VARCHAR(30) NOT NULL,
        username VARCHAR(50) NOT NULL,
        password VARCHAR(255) NOT NULL
    )";
    $dbh->exec($sql);
    echo "Table 'users' created successfully.";

    if (isset($_POST['submit'])) {
        // Get user input from the registration form
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Insert the user input into the 'users' table
        $sql = "INSERT INTO users (first_name, last_name, username, password)
            VALUES (:first_name, :last_name, :username, :password)";
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(':first_name', $first_name);
        $stmt->bindParam(':last_name', $last_name);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->execute();
        echo "User inserted successfully.";
    }

} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
