<!DOCTYPE html>
<html>
<head>

    <title>Registration Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
    <style>
        .jumbotron {
            background-image: linear-gradient(to right, #833ab4, #c13584, #681a9d);
            color: #fff;
        }

        input[type="text"], input[type="password"], .btn-primary, .btn-secondary {
            background-color: #6f42c1;
            border-color: #6f42c1;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="jumbotron text-center">
            <h2>Register to Play</h2>
        </div>




<?php
// Database information
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "testdb5";

// Connect to MySQL server and select the database
try {
    $dbh = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    // Set error mode to exception
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected to database successfully.";
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// Check if the form has been submitted
if(isset($_POST['create'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    
    // Check if the password and confirm password match
    if($password !== $confirm_password) {
        echo "<p>Passwords do not match.</p>";
    }
    else {
        // Check if the username already exists in the database
        $sql = "SELECT COUNT(*) FROM users WHERE username = ?";
        $stmt = $dbh->prepare($sql);
        $stmt->execute([$username]);
        $count = $stmt->fetchColumn();
        
        if($count > 0) {
            echo "<p>Username already exists. Please choose another username.</p>";
        }
        else {
            // Insert the user's information into the 'users' table
            $sql = "INSERT INTO users (first_name, last_name, username, password)
                    VALUES (?, ?, ?, ?)";
            $stmt = $dbh->prepare($sql);
            $stmt->execute([$first_name, $last_name, $username, $password]);
            echo "<p>Registration successful. Please <a href='Login.php'>log in</a>.</p>";
        }
    }
}

?>



<form action="" method="POST">
  <h2>Sign-Up</h2>
  <label for="username">Username:</label>
  <input type="text" id="username" name="username" required><br>

  <label for="password">Password:</label>
  <input type="password" id="password" name="password" required><br>

  <label for="confirm_password">Confirm Password:</label>
  <input type="password" id="confirm_password" name="confirm_password" required><br>

  <label for="first_name">First Name:</label>
  <input type="text" id="first_name" name="first_name" required><br>

  <label for="last_name">Last Name:</label>
  <input type="text" id="last_name" name="last_name" required><br>

  <button type="submit" name="create">Create</button>
  <button type="button" name="submit" onclick="location.href='Login.php'">Sign-In</button>
</form>
</div>
</body>
</html>







