<?php
$servername = "localhost";
$username = "root";
$password = "";


try {
    $conn = new PDO("mysql:host=$servername", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Check if database exists
    $query = "SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute(array('testdb5'));
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result['COUNT(*)'] > 0) {
        echo "Database exists!";
        

    } else {
    $sql = "CREATE DATABASE testdb5";
    // use exec() because no results are returned
    $conn->exec($sql);
    echo "Database created successfully<br>";
    }
} catch(PDOException $e) {
}
    // Database information
        $host = "localhost";
        $user = "root";
        $pass = "";
        $dbname = "testdb5";

        // Connect to MySQL server and select the database
        try {
            $dbh = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
            // Set error mode to exception
            $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "Connected to database successfully.";

            // Create the table for user information
            $sql = "CREATE TABLE IF NOT EXISTS users (
                    userId int NOT NULL AUTO_INCREMENT,
                    first_name varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
                    last_name varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
                    username varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
                    password varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
                    PRIMARY KEY (`userId`)
                    ) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $dbh->exec($sql);
            echo "Table 'users' created successfully.";

            // Create the table for session results
            $sql = "CREATE TABLE IF NOT EXISTS results (
                    resultId int NOT NULL AUTO_INCREMENT,
                    result varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
                    currentDate datetime NOT NULL,
                    numLives int NOT NULL DEFAULT '1',
                    userId varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
                    PRIMARY KEY (`resultId`),
                    KEY `fkuserId` (`userId`)
                    ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $dbh->exec($sql);
            echo "Table 'results' created successfully.";

            $sql = "CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `history` AS SELECT users.userId, users.first_name, users.last_name, results.result, results.numLives, results.currentDate
            FROM users, results
            WHERE users.userId = results.userId;";
            $dbh->exec($sql);
            echo "View 'history' created";


        } catch (PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        }
    
    


?>
