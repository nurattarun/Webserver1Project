<?php
$fail = "fail";
$pass = "pass";

function updateResultStatus($result){
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "testdb5";



    try {
       
        //Establish connection and retrieve data for current user
        $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        // set the PDO error mode to exception
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       //Update table for current user
         $sql = "SELECT userId FROM users WHERE username = :sesUser";
                    $stmt = $dbh->prepare($sql);
                    $stmt->execute([
                        'sesUser' => $_SESSION['username']
                    ]);

                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $userId = $row['userId'];

         $sql = "SELECT resultId FROM results WHERE userId = $userId";
                    $stmt = $dbh->prepare($sql);
                    $stmt->execute();
        
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $resultId = $row['resultId'];
        

        $sql = "UPDATE results SET result=$result, WHERE resultId= :resultId";

        // Prepare statement
        $stmt = $dbh->prepare($sql);

        // execute the query
        $stmt->execute([
                        'resultId' => $resultId
                    ]);

        // echo a message to say the UPDATE succeeded
        echo $stmt->rowCount() . " records UPDATED successfully";
        
    } catch(PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
}
function updateResultLives($numLives){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "testdb5";



    try {
       
        //Establish connection and retrieve data for current user
        $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        // set the PDO error mode to exception
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       //Update table for current user
         //Update table for current user
         $sql = "SELECT userId FROM users WHERE username = :sesUser";
                    $stmt = $dbh->prepare($sql);
                    $stmt->execute([
                        'sesUser' => $_SESSION['username']
                    ]);

                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $userId = $row['userId'];

         $sql = "SELECT resultId FROM results WHERE userId = $userId";
                    $stmt = $dbh->prepare($sql);
                    $stmt->execute();
        
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $resultId = $row['resultId'];;
        
        $sql = "UPDATE results SET `numLives`=`$numLives`, WHERE esultId= :resultId";

        // Prepare statement
        $stmt = $dbh->prepare($sql);

        // execute the query
        $stmt->execute([
                        'resultId' => $resultId
                    ]);


        // echo a message to say the UPDATE succeeded
        echo $stmt->rowCount() . " records UPDATED successfully";
        
    } catch(PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
}
?> 