<!DOCTYPE html>
<html>
<head>

    <title>Login Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
    <style>
        .jumbotron {
            background-image: linear-gradient(to right, #833ab4, #c13584, #681a9d);
            color: #fff;
        }

        input[type="text"], input[type="password"], .btn-primary, .btn-secondary {
            background-color: #6f42c1;
            border-color: #6f42c1;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="jumbotron text-center">
            <h2>Welcome to Game Quiz</h2>
        </div>
        <?php
            if(isset($_POST['login'])){
                $username = $_POST['username'];
                $password = $_POST['password'];

               
                // Verify username and password from database
                // If valid, redirect to home page
                // Otherwise, display error message
            } elseif (isset($_POST['signup'])) {
                // Redirect to the registration page
                header("Location: registration.php");
                exit();
            } elseif (isset($_POST['reset_password'])) {
                // Redirect to the reset password page
                header("Location: resetpass.php");
                exit();
            }
        ?>
        <form method="post" action="" class="form">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" class="form-control">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" class="form-control">
            </div>
            <div class="form-group">
                <input type="submit" name="login" value="Connect" class="btn btn-primary">
                <input type="submit" name="signup" value="Sign-Up" class="btn btn-secondary">
                <input type="submit" name="reset_password" value="Modify Password" class="btn btn-secondary">
            </div>
        </form>
                <?php
            include('mydb.php');
            include "livesCounter.php";
            if(isset($_POST['login']))
            {
                 //fill in the reLsult table with the information from the login
                $numLives = getLives();
                
                    $sql = "SELECT userId FROM users WHERE username = :sesUser";
                    $stmt = $dbh->prepare($sql);
                    $stmt->execute([
                        'sesUser' => $_POST['username']
                    ]);

                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $userId = $row['userId'];
                    // Get the current date and time in a MySQL datetime format
                    $date = date("Y-m-d H:i:s");

                    //Insert data into results table
                    $sql = "INSERT INTO results (result, currentDate, numLives, userId) VALUES ('incomplete', :date, $numLives, $userId)";
                    // use exec() because no results are returned
                    $stmt = $dbh->prepare($sql);
                    $stmt->execute([
                        'date' => $date
                    ]);
                    
                $username = $_POST['username'];
                $password = $_POST['password'];

                $stmt = $dbh->prepare("SELECT * FROM `users` WHERE username = :username AND password = :password");
                $stmt->bindParam(':username', $username);
                $stmt->bindParam(':password', $password);
                $stmt->execute();

                $row = $stmt->rowCount();

                if($row == 1)
                {
                    $_SESSION['username'] = $username;
                    echo '
                        <script>
                        alert("logged in");
                        window.location="level1.php";
                        </script>
                        ';
                }
                else
                {
                    echo '
                        <script>
                        alert("Please enter correct details!");
                        window.location="Login.php";
                        </script>
                        ';

                }

                //fill in the result table with the information from the login
                $numLives = getLives();
                try {
                    //Establish connection and retrieve data for current user
                    $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                    // set the PDO error mode to exception
                    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $sql = "SELECT userId, first_name, last_name FROM users WHERE username = :sesUser";
                    $stmt = $dbh->prepare($sql);
                    $stmt->execute([
                        'sesUser' => $_POST['username']
                    ]);

                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $userId = $row['userId'];
                    $firstname = $row['first_name'];
                    $lastname = $row['last_name'];

                    //Insert data into results table
                    $sql = "INSERT INTO results (result, first_name, last_name, numLives, userId)
                    VALUES ('incomplete', $firstname, $lastname, $numLives, $userId)";
                    // use exec() because no results are returned
                    $dbh->exec($sql);

                    
                } catch(PDOException $e) {
                    echo $sql . "<br>" . $e->getMessage();
                }
                
            }
        ?>

    </div>
</body>
</html>
