<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Final.css">
    <title>Game Level 1</title>
</head>
<body>
    <div class="topnav">
        <a class="active"  href="Login">Home</a>
        <a href="level1.php">New Game</a>
        <a href="Login.php">SignOut</a>
        <a href="history.php">History</a>
    </div>

</body>
</html>
<?php
function callHistoryPage(){
    ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "testdb5";
    // Connect to database
    $conn = mysqli_connect($servername,$username, $password, $dbname);
    // Retrieve data from database
    $query = "SELECT * FROM history";
    $result = mysqli_query($conn, $query);

    // Create HTML table
    echo "<table class='table'>";
    echo "<tr>
    <th>User ID</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Result</th>
    <th>Number Of Lives</th>
    <th>Date</th>
    </tr>";

    // Generate table rows dynamically
    while ($row = mysqli_fetch_assoc($result)) {
        // Insert data into table cells
        echo "<tr>";
        echo "<td>" . $row["userId"] . "</td>";
        echo "<td>" . $row["first_name"] . "</td>";
        echo "<td>" . $row["last_name"] . "</td>";
        echo "<td>" . $row["result"] . "</td>";
        echo "<td>" . $row["numLives"] . "</td>";
        echo "<td>" . $row["currentDate"] . "</td>";
        echo "</tr>";
    }

    echo "</table>";

    // Close database connection
    mysqli_close($conn);
}

echo callHistoryPage();
?>






