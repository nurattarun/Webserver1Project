
<?php include "livesCounter.php";

$lives = getLives();?>
<!-- HTML form -->
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Final.css">
    <title>Game Level 5</title>
</head>
<body>
    <div class="topnav">
        <a class="active"  href="Login">Home</a>
        <a href="level1.php">New Game</a>
        <a href="Login.php">SignOut</a>
		<a href="history.php">History</a>
    </div>



<?php
include "fillResultTable.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $letters = $_POST["letters"];
    $letters_array = str_split($letters); // convert the string to an array
    sort($letters_array); // sort the array alphabetically
    $first_letter_input = strtoupper($_POST["first_letter"]);
    $last_letter_input = strtoupper($_POST["last_letter"]);
    $first_letter = $letters_array[0]; // get the first letter from the sorted array
    $last_letter = $letters_array[5]; // get the last letter from the sorted array
    $first_letter_correct = $first_letter_input === $first_letter;
    $last_letter_correct = $last_letter_input === $last_letter;

    if ($first_letter_correct && $last_letter_correct) {
        echo "Congratulations! You correctly identified the first and last letters of the set.<br>";
        echo '<a href="level6.php">Next Level</a>';
    } else if ($_SESSION["lives"] < 6 ) {
        // Display wrong message
        echo '<p>Sorry, you sorted the letters incorrectly. Please try again.</p>';
        echo '<a href="level5.php" target="_self">Try Again</a>';
        incrementLives();
    } else {
        echo '<p>You are out of lives. Please try again from level 1.';
        echo '<a href="level1.php" target="_self">Try Again</a>';
        echo updateResultStatus($fail);
        echo updateResultLives($lives);
        $_SESSION["lives"] = 1;
    }
} else {
    echo "<p>Life: $lives </p>";?>

<h1>Game Level 5: Identify First and Last Alphabet</h1>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <label for="letters">Identify the first and last letters of this set of 6 different letters:</label>
    <br><br>
    <?php
    //array to generate letters
    $letters_array = array();
    for ($i = 0; $i < 6; $i++) {
        $letter = chr(rand(65, 90) ); // generates a random uppercase letter using ASCII code
        while (in_array($letter, $letters_array)) {
            $letter = chr(rand(65, 90)); //in_array checks if a given value exists in an array or not
        }
        array_push($letters_array, $letter);
    }
    shuffle($letters_array); // shuffles the letters
    $letters = implode("", $letters_array); // used to join elements of an array in a string
    echo "<p>$letters</p>";
    echo "<input type='hidden' name='letters' value='$letters'>";
    sort($letters_array); // sort the letters alphabetically
    $first_letter = $letters_array[0];
    $last_letter = $letters_array[5];
    ?>
    <label for="first_letter">First letter:</label>
    <input type="text-5" id="first_letter" name="first_letter" required maxlength="1"><br><br>
    <label for="last_letter">Last letter:</label>
    <input type="text-5" id="last_letter" name="last_letter" required maxlength="1"><br><br>
    <input type="submit" name="submit" value="Submit">
</form>
<br>
<?php
};
?>





