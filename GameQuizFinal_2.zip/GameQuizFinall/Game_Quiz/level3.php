<?php include "livesCounter.php";

$lives = getLives();?>
<!-- HTML form -->
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Final.css">
    <title>Game Level 3</title>
</head>
<body>
    <div class="topnav">
        <a class="active"  href="Login">Home</a>
        <a href="level1.php">New Game</a>
        <a href="Login.php">SignOut</a>
        <a href="history.php">History</a>

    </div>
    <?php
include "fillResultTable.php";

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the user's answers from the form submission
    $answers = $_POST['answers'];

    // Get the correct answers from the hidden inputs in the form
    $numbers = $_POST['numbers'];
    sort($numbers);

    // Check the user's answers against the correct answers
    $correct = true;
    for ($i = 0; $i < count($answers); $i++) {
        if ($answers[$i] != $numbers[$i]) {
            $correct = false;
            break;
        }
    }

    // Display the results
    if ($correct) {

        echo '<p>Congratulations! You sorted the numbers correctly.</p>';
        echo '<p>Your Numbers: '.implode(', ', $answers).'</p>';
        echo '<a href="Level4.php">Next Level</a>';
    }  else if($_SESSION["lives"] < 6 ) {
        // Display wrong message
        echo '<p>Sorry, you sorted the numbers incorrectly. Please try again.</p>';
        echo '<p>Your Letters: '.implode(', ', $input).'</p>';
        echo '<a href="Level3.php" target="_self">Try Again</a>';
        incrementLives();
   
    }else { 
        echo '<p>You are out of lives. Please try again from level 1.';
        echo '<a href="Level1.php" target="_self">Try Again</a>';
        echo updateResultStatus($fail);
        echo updateResultLives($lives);
        $_SESSION["lives"] = 1;
    }
} else {
    // Generate 6 random numbers
    $numbers = array();
    for ($i = 0; $i < 6; $i++) {
        $numbers[] = rand(0, 100);
    }
    shuffle($numbers);
    



     if (!isset($_POST['input'])) { // Display the form if it hasn't been submitted yet 
        $lives = getLives();
        echo "<p>Life: $lives </p>";?>
        
        <h1>Game Level 3: Order numbers in Ascending order</h1>
        <p>A set of 6 different numbers generated randomly is shown below. Please use the form available to write them in ascending order (from 0 to 100).</p>
        <p><?php echo implode(', ', $numbers); ?></p>
        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
            <?php foreach ($numbers as $number) { ?>
                <input type="hidden" name="numbers[]" value="<?php echo $number; ?>">
                <label>
                    <input type="number" name="answers[]" min="0" max="100" required>
                </label>
                <br>
            <?php } ?>
            <input type="submit" value="Submit">
        </form>
        <?php } ?>
    </body>
    </html>
    <?php } ;

