<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Final.css">
    <title>Sign Out</title>
</head>
<body>
    <p>You have been signed out succesfully.</p>
    <p>Login Again to to Start New Game</p>
    <a href="Login.php">Login</a>
</body>
</html>