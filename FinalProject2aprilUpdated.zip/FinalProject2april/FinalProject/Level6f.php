<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="Final.css">
	<title>Game Level 6</title>
</head>
<body>
	<div class="topnav">
		<a class="active" href="Login">Home</a>
		<a href="Level1f.php">New Game</a>
		<a href="SignOut.php">SignOut</a>
	</div>
	
<?php
include "livesCounter.php";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$numbers = $_POST["numbers"];
		$numbers_array = explode(", ", $numbers);
		$min_number = $_POST["min_number"];
		$max_number = $_POST["max_number"];

		// Check if the user's inputs match the generated numbers
		if (min($numbers_array) == $min_number && max($numbers_array) == $max_number) {
			echo "<p>Congratulations! You correctly identified the minimum and maximum numbers.</p><br>";
			echo '<a href="Level1f.php">Try Again</a>';

		} else if($_SESSION["lives"] < 6 ) {
        // Display wrong message
        echo '<p>Sorry, you sorted the numbers incorrectly. Please try again.</p>';
        echo '<a href="Level6f.php" target="_self">Try Again</a>';
        incrementLives();
   
    }else { 
        echo '<p>You are out of lives. Please try again from level 1.';
        echo '<a href="Level1f.php" target="_self">Try Again</a>';
        $_SESSION["lives"] = 1;
    }
	}else{?>
		<h1>Game Level 6: Identify the maximum and minimum numbers</h1>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		<label for="numbers">Identify the maximum and minimum numbers:</label>
		<br><br>
		<?php
		// Generate an array of 6 different random numbers
		$numbers_array = array();
		for ($i = 0; $i < 6; $i++) {
			$number = rand(1, 49); // generates a random number between 1 and 49
			while (in_array($number, $numbers_array)) {
				$number = rand(0, 100);
			}
			array_push($numbers_array, $number);
		}
		$numbers = implode(", ", $numbers_array); // join the numbers into a string
		echo "<p>$numbers</p>";
		echo "<input type='hidden' name='numbers' value='$numbers'>"; // store the numbers in a hidden input field
		?>
		<label for="min_number">Minimum number:</label>
		<input type="number-6" id="min_number" name="min_number" required required maxlength="2">
		<br><br>
		<label for="max_number">Maximum number:</label>
		<input type="number-6" id="max_number" name="max_number" required required maxlength="2">
		<br><br>
		<input type="submit" name="submit" value="Submit">
	</form>
</body>
</html>
	<?php };

