<?php 
if (!isset($_POST["submit"])){
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="Final.css">
</head>
<body>
<h1>Registration</h1>
    <form action="Login.php" method="post">
        <label for="firstName">First Name: </label>
        <input type="text-name" id="firstName" name="firstName"><br><br>
         <label for="lnalastNameme">Last Name: </label>
        <input type="text-name" id="lastName" name="lastName"><br><br>
         <label for="userName">User Name: </label>
        <input type="text-name" id="userName" name="userName"><br><br>
        <label for="password">Password: </label>
        <input type="password" id="password" name="password"><br><br>
        <label for="cPassword">Confirm Password: </label>
        <input type="password" id="confirmPassword" name="confirmPassword"><br><br>
        <input type="submit" value="Create" name="create">
        <input type="submit" value="Sign-In" name="submit">

    </form>
</body>
</html>
<?php
}
?>
<?php
// Check if the form has been submitted
if(isset($_POST['create'])) {

// Database information
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "DatabaseGame";

// Connect to MySQL server and select the database
try {
    $dbh = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    // Set error mode to exception
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected to database successfully.";
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

    $username = $_POST['userName'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirmPassword'];
    $first_name = $_POST['firstName'];
    $last_name = $_POST['lastName'];
    
    // Check if the password and confirm password match
    if($password !== $confirm_password) {
        echo "<p>Passwords do not match.</p>";
    }
    else {
        // Check if the username already exists in the database
        $sql = "SELECT COUNT(*) FROM users WHERE username = ?";
        $stmt = $dbh->prepare($sql);
        $stmt->execute([$username]);
        $count = $stmt->fetchColumn();
        
        if($count > 0) {
            echo "<p>Username already exists. Please choose another username.</p>";
        }
        else {
            // Insert the user's information into the 'users' table
            $sql = "INSERT INTO users (first_name, last_name, username, password)
                    VALUES (?, ?, ?, ?)";
            $stmt = $dbh->prepare($sql);
            $stmt->execute([$first_name, $last_name, $username, $password]);
            echo "<p>Registration successful.<a href='Login.php'>log in</a>.</p>";
        }
    }
}
?>



