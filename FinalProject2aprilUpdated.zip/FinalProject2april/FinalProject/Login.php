<!DOCTYPE html>
<html>
<head>
	<title>Login Form</title>
	<link rel="stylesheet" href="Final.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
</head>
<?php
session_start();
if(isset($_POST['connect'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];
	if(empty($username)) {
		echo "Please enter a username!";
	}elseif (empty($password)) {
		echo "Please enter a password!";
	} elseif(preg_match('/^[a-zA-Z0-9]+$/', $username) && $password == "password123") {
		
		// Code to validate the username and password in the database
		// Start session and redirect to game page
		session_start();
		$_SESSION['username'] = $username;
		header("Location: Level1f.php");
		exit();
	} else {
		echo "<p>Sorry, you entered a wrong username or password! <p>";
		echo '<a href="ResetPassword.php">Forgotten? Please, change your password.</a>';
	}
} elseif(isset($_POST['signup'])) {
	// Redirect to sign-up page
	header("Location: Signup.php");
	exit();
}
include('dbConnection.php');
if(isset($_POST['connect']))
{
	$username = $_POST['username'];
	$password = $_POST['password'];

	$query = mysqli_query($conn, "SELECT * FROM `admin` WHERE username ='$username' and password ='$password'");
	$row = mysqli_num_rows($query);
	if($row == 1)
	{
		$_SESSION['admin'] = 'admin';
		echo'
			<script>
			alert("logged in");
			window.location="level5.php";
			</script>
			';
	}
	else
	{
		echo'
			<script>
			alert("Please enter correct details!");
			window.location="Login.php";
			</script>
			';

	}
}
        ?>
<?php if (isset($_POST['submit'])){?>

<body>
	<h1>Login Form</h1>
	<form method="post" action="Login.php">
		<label>Username:</label><br>
		<input type="text-name" name="username"><br>
		<label>Password:</label><br>
		<input type="password" name="password"><br><br>
		<input type="submit" name="connect" value="Connect">
		<input type="submit" name="signup" value="Sign-Up">
	</form>
</body>
</html>
<?php };?>