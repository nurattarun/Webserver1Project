I wasn't able to adjust the login page to properly integrate the database

Login page, line 40, where does the varialble $conn come from

I was trying to figure out what was wrong witht he validation on level 5 and level 6, i think i figured out level 6 but im not sure 