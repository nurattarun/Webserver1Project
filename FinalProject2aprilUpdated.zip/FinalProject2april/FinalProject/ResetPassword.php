<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="Final.css">
	<title>Reset Password</title>
</head>
<body>
	<h1>Reset Password</h1>
	<form method="post" action="reset_password.php">
		<label>Username:</label><br>
		<input type="text-name" name="username"><br>
		<label>New Password:</label><br>
		<input type="password" name="new_password"><br>
		<label>Re-Enter New Password:</label><br>
		<input type="password" name="re-enter_new_password"><br><br>
		<input type="submit" name="reset" value="Reset">
	</form>
</body>
</html>

<?php
if(isset($_POST['reset'])) {
	$username = $_POST['username'];
	$new_password = $_POST['new_password'];
	// Code to reset the password in the database for the given username
	if($username == "admin") {
		// For demo purposes, set the new password to a fixed value
		$new_password_hash = password_hash("new_password", PASSWORD_DEFAULT);
		// Code to update the password in the database
		echo "Password reset successfully!";
		// Redirect the user to the login page
		header("Location: Login.php");
		exit();
	} else {
		echo "Username not found!";
	}
}
?>
