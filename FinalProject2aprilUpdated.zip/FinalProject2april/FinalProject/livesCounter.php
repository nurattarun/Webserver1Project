<?php
session_start();

// Initialize lives to 6 if it doesn't exist in the session
if (!isset($_SESSION['lives'])) {
  $_SESSION['lives'] = 1;
}

// Function to decrement lives
function decrementLives() {
  if ($_SESSION['lives'] > 0) {
    $_SESSION['lives']--;
  }
}

// Function to increment lives
function incrementLives() {
  if ($_SESSION['lives'] < 6) {
    $_SESSION['lives']++;
  }
}

// Function to get current lives
function getLives() {
  return $_SESSION['lives'];
}
