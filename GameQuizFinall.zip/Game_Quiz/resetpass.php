<?php

// Database information
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "testdb5";

// Connect to MySQL server and select the database
try {
    $dbh = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    // Set error mode to exception
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if username exists in the users table
    $username = $_POST['username'];
    $stmt = $dbh->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result['COUNT(*)'] > 0) {
        echo "Username exists in the database!";
    } else {
        echo "Username does not exist in the database.";
    }

} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

?>
